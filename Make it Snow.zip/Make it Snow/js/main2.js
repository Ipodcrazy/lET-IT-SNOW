// TITLE

// Load canvas
let cnv = document.getElementById("myCanvas");
let ctx = cnv.getContext("2d");
cnv.width = 2000;
cnv.height = 1000;

// Global Variables
let snowballs = [];

ctx.fillStyle = 'black';
ctx.fillRect(0, 0, cnv.width, cnv.height);

// Event Listener
document.addEventListener("keydown", keyDownEvent);

// Event Function
function keyDownEvent(event){
    if (event.key == "1") {
        for (i = 0; i < 5; i++) {
            snowballs.pop();
            console.log("Snowballs gone");
        }
    }
    else if (event.key == "2") {
        for (i = 0; i < 5; i++) {
            snowballs.push({
                x: Math.floor(Math.random() * cnv.width),
                y: 100,
                r: Math.random() * 10,
                speed: Math.floor(Math.random() * 5 + 1)
            })
        }
        console.log("Added snow");
    }
}



//creating the first snowballs
for (let i = 0; i < 20; i++) {
    snowballs.push({
        x: Math.floor(Math.random() * cnv.width),
        y: 100,
        r: Math.random() * 10,
        speed: Math.floor(Math.random() * 5 + 1)
    })
}


console.log(snowballs);

// Frame Making
requestAnimationFrame(draw);
function draw() {

    // Redraw the background
    ctx.fillStyle = 'black';
    ctx.fillRect(0, 0, cnv.width, cnv.height);

    // Draw the snowballs
    for (let i = 0; i < snowballs.length; i++) {
        ctx.fillStyle = "white";
        ctx.beginPath();
        ctx.arc(snowballs[i].x, snowballs[i].y, snowballs[i].r, 0, 2 * Math.PI);
        ctx.fill();
    }

    // Update Snowball location
    for (let i = 0; i < snowballs.length; i++) {
        snowballs[i].y += snowballs[i].speed;
    }

    snowballs.push({
        x: Math.floor(Math.random()*cnv.width),
        y: 100,
        r: Math.random() * 10,
        speed: Math.floor(Math.random() * 6 + 1)
    })

    for (let i = 0; i < snowballs.length; i++) {
        if (snowballs[i].y >= cnv.height) {
            snowballs[i].y = 0;
            snowballs[i].x = Math.floor(Math.random() * cnv.width + 1);
        }
    }

    requestAnimationFrame(draw);
}
